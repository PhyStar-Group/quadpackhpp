﻿// quadpackhpp.h: 标准系统包含文件的包含文件
// 或项目特定的包含文件。

#pragma once
#include <iostream>
#include <math.h>
#include <algorithm>
#include <float.h>
#include <concepts>

namespace quadpack {
constexpr auto uflow = DBL_MIN;
constexpr auto oflow = DBL_MAX;
constexpr auto epmach = DBL_EPSILON;
constexpr auto LIMIT = 1000;
constexpr auto MAXP1 = 21;
constexpr auto Pi = 3.14159265358979323846;
constexpr auto COSINE = 1;
constexpr auto SINE = 2;
constexpr auto FALSE = 0;
constexpr auto TRUE = 1;

#ifndef min
#define min(a,b)    (((a) < (b)) ? (a) : (b))
#endif
#ifndef max
#define max(a,b)    (((a) > (b)) ? (a) : (b))
#endif


    template<typename T>
    concept realtype = std::is_floating_point<T>::value;//只允许浮点数

//    typedef T_real(*dq_function_type)(T_real, void*);
    template<realtype T_real>
    using qwgt = T_real(*)(T_real, T_real, T_real, T_real, T_real, int);
    /* Integration routines */
    /* Gauss-Kronrod for integration over finite range. */
    template<typename T_fun, realtype T_real = double>
    T_real gk15(T_fun f, T_real user_data[], T_real a, T_real b, T_real* abserr, T_real* resabs, T_real* resasc);
    template<typename T_fun, realtype T_real = double>
    T_real gk21(T_fun f, T_real user_data[], T_real a, T_real b, T_real* abserr, T_real* resabs, T_real* resasc);
    template<typename T_fun, realtype T_real = double>
    T_real gk31(T_fun f, T_real user_data[], T_real a, T_real b, T_real* abserr, T_real* resabs, T_real* resasc);
    template<typename T_fun, realtype T_real = double>
    T_real gk41(T_fun f, T_real user_data[], T_real a, T_real b, T_real* abserr, T_real* resabs, T_real* resasc);
    template<typename T_fun, realtype T_real = double>
    T_real gk51(T_fun f, T_real user_data[], T_real a, T_real b, T_real* abserr, T_real* resabs, T_real* resasc);
    template<typename T_fun, realtype T_real = double>
    T_real gk61(T_fun f, T_real user_data[], T_real a, T_real b, T_real* abserr, T_real* resabs, T_real* resasc);

    /* Gauss-Kronrod for integration over infinite range. */
    template<typename T_fun, realtype T_real = double>
    T_real gk15i(T_fun f, T_real user_data[],T_real boun, int inf, T_real a, T_real b, T_real* abserr, T_real* resabs, T_real* resasc);

    /* Gauss-Kronrod for integration of weighted function. */
    template<typename T_fun, realtype T_real = double>
    T_real gk15w(T_fun f, T_real user_data[], qwgt<T_real> w, T_real p1, T_real p2, T_real p3, T_real p4, int kp, T_real a, T_real b, T_real* abserr,
        T_real* resabs, T_real* resasc);
    template<realtype T_real = double>
    T_real qext(int* n, T_real epstab[], T_real* abserr, T_real res3la[], int* nres);
    template<realtype T_real = double>
    void qsort(int limit, int last, int* maxerr, T_real* ermax, T_real elist[], int iord[], int* nrmax);
    template<typename T_fun, realtype T_real = double>
    T_real qagi(T_fun f, T_real user_data[], T_real bound, int inf, T_real epsabs, T_real epsrel, T_real* abserr, int* neval, int* ier);
    template<typename T_fun, realtype T_real = double>
    T_real qags(T_fun f, T_real user_data[], T_real a, T_real b, T_real epsabs, T_real epsrel, T_real* abserr, int* neval, int* ier);
    template<typename T_fun, realtype T_real = double>
    T_real qagp(T_fun f,T_real user_data[], T_real a, T_real b, int npts2, T_real* points, T_real epsabs, T_real epsrel, T_real* abserr, int* neval, int* ier);
    template<typename T_fun, realtype T_real = double>
    T_real qng(T_fun f, T_real user_data[], T_real a, T_real b, T_real epsabs, T_real epsrel, T_real* abserr, int* neval, int* ier);
    template<typename T_fun, realtype T_real = double>
    T_real qag(T_fun f, T_real user_data[],T_real a, T_real b, T_real epsabs, T_real epsrel, int irule, T_real* abserr, int* neval, int* ier);
    template<typename T_fun, realtype T_real = double>
    T_real qage(T_fun f, T_real user_data[], T_real a, T_real b, T_real epsabs, T_real epsrel, int irule, T_real* abserr, int* neval, int* ier, int* last);
    template<realtype T_real = double>
    T_real qwgtc(T_real x, T_real c, T_real p2, T_real p3, T_real p4, int kp);
    template<realtype T_real = double>
    T_real qwgto(T_real x, T_real omega, T_real p2, T_real p3, T_real p4, int integr);
    template<realtype T_real = double>
    T_real qwgts(T_real x, T_real a, T_real b, T_real alpha, T_real beta, int integr);
    template<realtype T_real = double>
    void qcheb(T_real* x, T_real* fval, T_real* cheb12, T_real* cheb24);
    template<typename T_fun, realtype T_real = double>
    T_real qc25o(T_fun f, T_real user_data[], T_real a, T_real b, T_real omega, int integr, int nrmom, int maxp1, int ksave, T_real* abserr, int* neval,
        T_real* resabs, T_real* resasc, int* momcom, T_real** chebmo);
    template<typename T_fun, realtype T_real = double>
    T_real qfour(T_fun f, T_real user_data[], T_real a, T_real b, T_real omega, int integr, T_real epsabs, T_real epsrel, int icall, int maxp1,
        T_real* abserr, int* neval, int* ier, int* momcom, T_real** chebmo);
    template<typename T_fun, realtype T_real = double>
    T_real qawfe(T_fun f, T_real user_data[], T_real a, T_real omega, int integr, T_real epsabs, int limlst, int maxp1, T_real* abserr, int* neval, int* ier,
        T_real* rslst, T_real* erlist, int* ierlst, T_real** chebmo);
    template<typename T_fun, realtype T_real = double>
    T_real qawf(T_fun f, T_real user_data[], T_real a, T_real omega, int integr, T_real epsabs, T_real* abserr, int* neval, int* ier);
    template<typename T_fun, realtype T_real = double>
    T_real qawo(T_fun f, T_real user_data[], T_real a, T_real b, T_real omega, int integr, T_real epsabs,
        T_real epsrel, T_real* abserr, int* neval, int* ier);
    template<typename T_fun, realtype T_real = double>
    T_real qaws(T_fun f, T_real user_data[], T_real a, T_real b, T_real alfa, T_real beta, int wgtfunc,
        T_real epsabs, T_real epsrel, T_real* abserr, int* neval, int* ier);
    template<typename T_fun, realtype T_real = double>
    T_real qawse(T_fun f, T_real user_data[], T_real a, T_real b, T_real alfa, T_real beta,
        int wgtfunc, T_real epsabs, T_real epsrel, T_real* abserr,
        int* neval, int* ier);
    template<realtype T_real = double>
    void qmomo(T_real alfa, T_real beta, T_real ri[], T_real rj[], T_real rg[], T_real rh[], int wgtfunc);
    template<typename T_fun, realtype T_real = double>
    T_real qc25s(T_fun f, T_real user_data[], T_real a, T_real b, T_real bl, T_real br, T_real alfa,
       T_real beta, T_real ri[], T_real rj[], T_real rg[], T_real rh[],
        T_real* abserr, T_real* resasc, int wgtfunc, int* nev);
    template<typename T_fun, realtype T_real = double>
    T_real qc25c(T_fun f, T_real user_data[], T_real a, T_real b, T_real c, T_real* abserr,
        int* krul, int* neval);
    template<typename T_fun, realtype T_real = double>
    T_real qawc(T_fun f, T_real user_data[], T_real a, T_real b, T_real c, T_real epsabs,
        T_real epsrel, T_real* abserr, int* neval, int* ier);
    template<typename T_fun, realtype T_real = double>
    T_real qawce(T_fun f, T_real user_data[], T_real a, T_real b, T_real c, T_real epsabs,
        T_real epsrel, T_real* abserr, int* neval, int* ier);
}
#include"gk15.hpp"
#include"gk21.hpp"
#include"gk31.hpp"
#include"gk41.hpp"
#include"gk51.hpp"
#include"gk61.hpp"
#include"gk15i.hpp"
#include"gk15w.hpp"
#include"qext.hpp"
#include"qsort.hpp"
#include"qagi.hpp"
#include"qags.hpp"
#include"qagp.hpp"
#include"qng.hpp"
#include"qag.hpp"
#include"qage.hpp"
#include"qwgt.hpp"
#include"qcheb.hpp"
#include"qc25o.hpp"
#include"qfour.hpp"
#include"qawfe.hpp"
#include"qawf.hpp"
#include"qawo.hpp"
#include"qaws.hpp"
#include"qawse.hpp"
#include"qmomo.hpp"
#include"qc25s.hpp"
#include"qc25c.hpp"
#include"qawc.hpp"
#include"qawce.hpp"
// TODO: 在此处引用程序需要的其他标头。
